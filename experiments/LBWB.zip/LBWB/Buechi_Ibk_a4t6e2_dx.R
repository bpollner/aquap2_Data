
fileExtension <- ".dx"
##
spectralImport <- function(dataFile) {

	####
	
	key2names <- function(key) {
		gsub ("[[:blank:]_-]", "", tolower (key))
	} # EOF	
	
	jdx_readhdr <- function(hdr) {

	  ## get rid of comments. JCAMP-DX comments start with $$ and go to the end of the line.
	  hdr <- hdr [! grepl ("^[[:blank:]]*[$][$]", hdr)]
	  hdr <- gsub ("([[:blank:]][$][$].*)$", "", hdr)

	  ## now join lines that are not starting with ##KEY= with the KEYed line before
	  nokey <- grep ("^[[:blank:]]*##.*=", hdr, invert = TRUE)
	  if (length (nokey) > 0) {
		for (l in rev (nokey)) # these are few, so no optimization needed
			hdr [l - 1] <- paste (hdr [(l - 1) : l], collapse = " ")
		hdr <- hdr [-nokey]
	  }

	  names <-  key2names (sub ("^[[:blank:]]*##(.*)=.*$", "\\1", hdr))
  
	  hdr <- sub ("^[[:blank:]]*##.*=[[:blank:]]*(.*)[[:blank:]]*$", "\\1", hdr)
	  hdr <-   gsub ("^[\"'[:blank:]]*([^\"'[:blank:]].*[^\"'[:blank:]])[\"'[:blank:]]*$", "\\1", hdr)
	  i <- grepl ("^[[:blank:]]*[-]?[.[:digit:]]*[eE]?[-]?[.[:digit:]]*[[:blank:]]*$", hdr)
	  hdr <- as.list (hdr)
	  hdr [i] <- as.numeric (hdr [i])
	  names (hdr) <- names

	  ## e.g. Shimadzu does not always save XFACTOR and YFACTOR
	  if (is.null (hdr$yfactor)) hdr$yfactor <- 1
	  if (is.null (hdr$xfactor)) hdr$xfactor <- 1

	  ## we treat XYDATA and PEAK TABLEs the same way
	  format <- hdr [names (hdr) %in% key2names(dataStartString)]
	  format <- format [! sapply (format, is.null)]
	  if (length (format) != 1) { stop ("contradicting format specification.") }
	  hdr$.format <- format [[1]]
	  return(hdr)
} # EOF

	jdx_tabular_pac <- function (hdr, Data, ..., xtol = hdr$xfactor) {

		## regexp for numbers including scientific notation
		.PATTERN.number <- "[0-9]*[.]?[0-9]*([eE][+-]?[0-9]+)?"
  
		if (is.null (hdr$firstx))  stop ("##FIRSTX= missing.")
		if (is.null (hdr$lastx))   stop ("##LASTX= missing.")
		if (is.null (hdr$npoints)) stop ("##NPOINTS= missing.")
  
		wl <- seq (hdr$firstx, hdr$lastx, length.out = hdr$npoints)

		## remove starting X
		y <- sub (paste0 ("^[[:blank:]]*", .PATTERN.number, "[[:blank:]]*(.*)$"), "\\2", Data)

		## add spaces between numbers if necessary
		y <- gsub ("([0-9.])([+-])", "\\1 \\2", y)

		y <- strsplit (y, "[[:blank:]]+")
		ny <- sapply (y, length)

		y <- as.numeric (unlist (y))

		if (length (y) != hdr$npoints)
			stop ("mismatch between ##NPOINTS and length of Y data.")

		## X checkpoints
		x <- sub (paste0 ("^[[:blank:]]*(", .PATTERN.number, ")[[:blank:]]*.*$"), "\\1", Data)
		x <- as.numeric (x) * hdr$xfactor
		diffx <- abs (wl [c (1, head (cumsum (ny) + 1, -1))] - x)
		if (any (diffx > xtol))
			message ("JDX file inconsistency: X axis differs from checkpoints. ", sprintf ("Maximum difference = %0.2g (%0.2g * XFACTOR)", max(diffx), max(diffx) / hdr$xfactor))
		
		y <- y * hdr$yfactor
		return(y)
		# return (matrix(y, nrow=1))
		# new ("hyperSpec", spc = y, wavelength = wl)
	} # EOF

	jdx_checkYvalues <- function(yval, hdr) {
		ytol <- hdr$yfactor
		miny <- min(yval)
		if (! is.null (hdr$miny) && abs(hdr$miny - miny) > ytol) {
			message (sprintf ("JDX file inconsistency: Minimum of spectrum != MINY: difference = %0.3g (%0.3g * YFACTOR)", miny - hdr$miny, (miny - hdr$miny) / hdr$yfactor))
		}
		maxy <- max(yval)
		if (! is.null (hdr$maxy) && abs(hdr$maxy - maxy) > ytol) {
			message (sprintf ("JDX file inconsistency: Maximum of spectrum != MAXY: difference = %0.3g (%0.3g * YFACTOR)", maxy - hdr$maxy, (maxy - hdr$maxy) / hdr$yfactor))
		}
	} # EOF
	
	####

	## adapted from code from the package "hyperSpec"

	dataStartString <- "XYDATA"
	roundWlnm <- 2 # the number to which the wavelength in nm should be rounded
	cpwl <- "w" # the characters that go before the wavelength
	nrConScans <- getmd()$postProc$nrConScans # get the number of consecutive scans from the metadata
	checkYvalues <- FALSE
	minTransmitValue <- 0.001	# the minimum value of transmittance that is acceptable
	#
	fCon <- file(dataFile, "r")
	jdx <- readLines(fCon) # read the whole file as character
	close (fCon)
	#
	nrBlocks <- as.numeric(unlist(strsplit(jdx[4], "##BLOCKS= "))[2])
	hdrstart <- grep ("^[[:blank:]]*##TITLE=", jdx)
	hdrstart <- hdrstart[-1] # because the first is not a header
	if (length (hdrstart) == 0L) { stop ("No spectra found.") }
	datastart <- grep (sprintf ("^[[:blank:]]*##(%s)=", dataStartString), jdx) + 1
	dataend <- grep ("^[[:blank:]]*##", jdx)
	dataend <- sapply (datastart, function(dse) dataend [which (dataend > dse)[1]] ) - 1
  	
  	spcend <- grep ("^[[:blank:]]*##END=[[:blank:]]*$", jdx) - 1 ## ???

	## some checks
	stopifnot(length (datastart) >= length (hdrstart))
	stopifnot(length (datastart) == length (dataend))
	stopifnot(all (hdrstart < spcend))
	stopifnot(all (datastart < dataend))
	stopifnot(nrBlocks == length(datastart))

	aaa <- jdx_readhdr(jdx[hdrstart[1]:(datastart[1]-1)]) # the first header
	nPoints <- aaa$npoints
	wns <- rev(seq(aaa$firstx, aaa$lastx, by=aaa$deltax)) # the (reverted) sequence of x in wavenumbers
	if (length(wns) != nPoints) { stop("Error in X-Axis calculation", call.=FALSE) }
	wlnm <- round( (1e7/wns), roundWlnm) # the wavenumbers transformed to nm wavelength
	wls <- paste(cpwl, wlnm, sep="") # paste the characters before each number
	#
	NIR <- as.data.frame(matrix(NA, nrow=nrBlocks, ncol=nPoints))
	refsInd <- rep(FALSE, nrBlocks)
	tsa <- matrix(NA, nrow=nrBlocks, ncol=1) # the data frame to be filled for the timestamps
	for (i in 1 : length(datastart)) { ## CORE -- data extraction
		hdr <- jdx_readhdr(jdx[hdrstart[i]: (datastart[i]-1)])
		if (is.numeric(hdr[[1]]) & !is.na(hdr[[1]])) { # all the reference scans have an numeric title (first header element)
			refsInd[i] <- TRUE
		}
		y <- jdx_tabular_pac(hdr, jdx[datastart[i]:dataend[i]]) # returns vector !
		if (checkYvalues) {
			jdx_checkYvalues(y, hdr) # check the values in the single row of NIR
		}
		NIR[i,] <- y
		dateTimePosix <- as.POSIXct(strptime(paste(hdr$date, hdr$time, sep=" "), "%y/%m/%d %H:%M:%S")) 
		tsa[i,1] <- dateTimePosix		# separately for de-bugging
	} # end for i
	refsInd <- rev(refsInd)	
	tsa <- rev(tsa[,1]) # turn into vector and revert
	tsa <- as.POSIXct(tsa, origin=strptime("01.01.1970", format="%d.%m.%Y"))
	tsa <- data.frame(TS=tsa)
	NIRall <- apply(rev(NIR), 2, rev) # turn around all the columns so that it matches the wavelengths in nm; turn around the rows as well so that we get the measurement order
 	aaa <- which(refsInd) # we get the indices for all that are TRUE, that is for all the reference scans
	NIR <- NIRall[-aaa,]	 	# get rid of the reference scans
	NIR[NIR < minTransmitValue] <- minTransmitValue	 # clean out all the values that are below the minimim transmittance value (see above)
	NIR <- log10(1/NIR) 	# transform to absorbance  XXX CORE XXX
	timestamp <- tsa[-aaa, , drop=FALSE] # get rid of the reference scans
	refs <- cbind(tsa[aaa,,drop=FALSE], NIRall[aaa,])  # only the reference scans
	colnames(refs) <- c("ts", wls)
	rownames(refs) <- paste("Ref", 1:nrow(refs), sep="")
	save(refs, file="R-data/refs"); rm(refs)
    #
   	sampleNr <- conSNr <- timePoints <-	ecrm <- repl <- group <- temp <- relHum <- C_cols <- Y_cols <- NULL
   	info <- list(nCharPrevWl = nchar(cpwl))
   	NIR <- as.matrix(NIR)
   	colnames(NIR) <- wls
   	rownames(NIR) <- paste("S", 1:nrow(NIR), sep="")
   	colnames(timestamp) <- "Time"
   	rownames(timestamp) <- paste("S", 1:nrow(NIR), sep="")
   	#
   	return(list(sampleNr=sampleNr, conSNr=conSNr, timePoints=timePoints, ecrm=ecrm, repl=repl, group=group, temp=temp, relHum=relHum, C_cols=C_cols, Y_cols=Y_cols, timestamp=timestamp, info=info, NIR=NIR))
 } # EOF

