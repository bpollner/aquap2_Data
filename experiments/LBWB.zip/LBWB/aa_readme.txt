LBWB

A simple dataset without much scientific meaning. Just to demonstrate the custom import function of aquap2. 

Three different liquids were recorded in **non** randomized order:
Tap water, two different preparations of liquid broth (LB), and LB with bacteria growing in them.


Spectrometer was a Büchi Benchtop device with Peltier element temperature control.

Date were recorded at the Institute for Analytical Chemistry, University of Innsbruck, courtesy of Prof. Christian Huck. 

