xsComp
A small comparison of some water species


No treatment, no intervention — just 3 replicates of a water-species.

Used waters:
StU — St. Ulrich (A)
Ob — Oberndorf (A)
Bx — Brixen (A)
GrB —  watet GrB (A)
GrW —  water GrW (A)
We — water We (NL)
MQs — the env. control (J)
Dist — distilled water (J)

8 waters, 3 replicates each
8 x 3 = 24 

MQ spacing = 8
5 consecutive spectra

Spectrometer: FOSS XDS, liquid module, quartz cuvette 1mm path length
Location and time: Kobe, Japan. Measured in ~July. 